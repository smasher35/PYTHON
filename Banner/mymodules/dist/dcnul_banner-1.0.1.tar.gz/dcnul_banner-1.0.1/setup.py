from setuptools import setup


setup(
    name='dcnul_banner',
    version='1.0.1',
    description='Script banner with some programmer data',
    author='d3fc0nnull',
    author_email='smasher35@gmail.com',
    url='https://www.youtube.com/channel/UCLNgMNfdksu_r5cwlplenBg',
    py_modules=['banner'],
)

